rm(list = ls())

setwd("C:/Users/")
#arrange everything in the excel file before loading in here
#this will be the same format as EAGtext when loaded
feminist <- read.csv("Feminist Metadata.csv")
#load all of the necessary packages first
library(gutenbergr)
library(ggplot2)
library(tidytext) #does this one need to be loaded last??
library(stringr)
library(NLP)
library(tm)  # make sure to load this prior to openNLP
library(openNLP)
library(openNLPmodels.en)
library(tidyverse)
library(ggtext)
library(glue)
library(Rmisc)

library(dplyr) #dplyr needs to be loaded last

feminist <- feminist[,-c(4)]
feminist$text <- as.character(feminist$text)
feminist$title <- as.character(feminist$title)
feminist$Author <- as.character(feminist$Author)
feminist$Publication.Journal <- as.character(feminist$Publication.Journal)
feministMini <- feminist[,-c(3, 4, 5)]

feministSumm <- feminist %>%
  unnest_tokens(word, text)

feministClean <- dplyr::count(feministSumm, ID, title, Publication.Year, Publication.Journal, word, sort = TRUE)

feministClean$sum <- NA
for(val in unique(feministClean$title)) {
  feministClean$sum[feministClean$title == val] <- sum(feministClean$n[feministClean$title == val])
}
#####
unique(feminist$Publication.Journal)
feministClean$country <- NA
for (val in unique(feministClean$Publication.Journal)) {
  feministClean$country[feministClean$Publication.Journal == "The Massachusetts Review"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "Contemporary Literature"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "Kunapipi"] <- "International"
  feministClean$country[feministClean$Publication.Journal == "Caribbean Quarterly"] <- "Caribbean"
  feministClean$country[feministClean$Publication.Journal == "Tulsa Studies in Women's Literature"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "Critical Inquiry"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "MFS Modern Fiction Studies"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "Victorian Studies"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "Twentieth Century Literature"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "College Literature"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "Callaloo"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "Journal of Caribbean Literatures"] <- "Caribbean"
  feministClean$country[feministClean$Publication.Journal == "Proceedings of The National Conference On Undergraduate Research"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "EUROPEAN ACADEMIC RESEARCH"] <- "International"
  feministClean$country[feministClean$Publication.Journal == "Edinburgh University Press"] <- "UK"
  feministClean$country[feministClean$Publication.Journal == "Duke University Press"] <- "US"
  feministClean$country[feministClean$Publication.Journal == "Cambridge University Press"] <- "UK"
  feministClean$country[feministClean$Publication.Journal == "Cornell University Press"] <- "US"
}
#####

#remove stop words
feministClean <- feministClean %>%
  anti_join(stop_words)
#clean up by removing numbers and meta info
temporary <- feministClean[grep("1", feministClean$word),]
temporary <- rbind(temporary, feministClean[grep("2", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("3", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("4", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("5", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("6", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("7", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("8", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("9", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("0", feministClean$word),])
temporary <- rbind(temporary, feministClean[grep("jstor", feministClean$word),])
feministClean <- feministClean %>%
  anti_join(temporary)

feministClean

book_tf_idf <- feministClean %>%
  bind_tf_idf(word, title, n)

##word frequency##
#search for 'feminism/feminist', 'woman/women', 'Jean Rhys', 'patriarchy', 'sexism', 'misogyny', 'misandry', 'male gaze', 'privilege'
book_tf_idf[grep("feminis", book_tf_idf$word),]
book_tf_idf[book_tf_idf$word == "feminist",]
class(book_tf_idf$ID)
book_tf_idf$ID <- as.factor(book_tf_idf$ID)

#experimental analyses
femWords <- book_tf_idf[book_tf_idf$word == "feminist",]
ggplot(femWords, aes(x = ID, y = n)) + 
  geom_bar(stat = "identity") +
  xlab("Text ID") +
  ylab("Frequency")
###feminist terms###
femWords <- book_tf_idf[book_tf_idf$word == "feminist",]
femWords <- rbind(femWords, book_tf_idf[book_tf_idf$word == "feminism",])
femWords <- rbind(femWords, book_tf_idf[book_tf_idf$word == "women",])
femWords <- rbind(femWords, book_tf_idf[book_tf_idf$word == "patriarchy",])
femWords <- rbind(femWords, book_tf_idf[book_tf_idf$word == "sex",])
femWords <- rbind(femWords, book_tf_idf[book_tf_idf$word == "gender",])
femWords <- rbind(femWords, book_tf_idf[book_tf_idf$word == "feminine",])
femWords <- rbind(femWords, book_tf_idf[book_tf_idf$word == "sexism",])
femWords <- rbind(femWords, book_tf_idf[book_tf_idf$word == "misogyny",])

#for(val in unique(femWords$word)) {
#  
#}
#femWords$femTerms <- 

  
femWordSumm <- data.frame("ID" = unique(femWords$ID), "title" = unique(femWords$title), "sum" = unique(femWords$sum))
for(val in unique(femWords$title)) {
  femWordSumm$femSum[femWordSumm$title == val] <- sum(femWords$n[femWords$title == val])
  femWordSumm$femSD[femWordSumm$title == val] <- sd(femWords$n[femWords$title == val])
  femWordSumm$femSE[femWordSumm$title == val] <- sd(femWords$n[femWords$title == val])/
    sqrt(length(sd(femWords$n[femWords$title == val])))
}
ggplot(femWordSumm, aes(x = ID, y = femSum/sum)) + 
  geom_bar(stat = "identity") +
  xlab("Text ID") +
  ylab("Frequency") +
  ggtitle("Frequency of Feminist Terms by Text")
femWordYear <- data.frame("Publication.Year" = unique(femWords$Publication.Year))
for(val in unique(femWords$Publication.Year)) {
  femWordYear$femSum[femWordYear$Publication.Year == val] <- sum(femWords$n[femWords$Publication.Year == val])
  femWordYear$sum[femWordYear$Publication.Year == val] <- sum(femWords$sum[femWords$Publication.Year == val])
}
ggplot(femWordYear, aes(x = Publication.Year, y = femSum/sum)) + 
  #geom_bar(stat = "identity") +
  geom_line(stat = "identity") +
  xlab("Year") +
  ylab("Frequency") +
  ggtitle("Frequency of Feminist Terms by Year")

femWordPlace <- data.frame("country" = unique(femWords$country))
for(val in unique(femWords$country)) {
  femWordPlace$femSum[femWordPlace$country == val] <- sum(femWords$n[femWords$country == val])
  femWordPlace$sum[femWordPlace$country == val] <- sum(femWords$sum[femWords$country == val])
}
ggplot(femWordPlace, aes(x = country, y = femSum/sum)) + 
  geom_bar(stat = "identity") +
  xlab("Country of Publication") +
  ylab("Frequency") +
  ggtitle("Frequency of Feminist Terms by Country of Publication")


###compare male vs female language###
menWords <- book_tf_idf[book_tf_idf$word == "male",]
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "men",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "man",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "father",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "brother",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "son",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "husband",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "patriarchy",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "patrimony",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "women",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "female",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "woman",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "mother",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "sister",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "daughter",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "wife",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "matriarchy",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "matrimony",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "people",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "person",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "partner",])
menWords <- rbind(menWords, book_tf_idf[book_tf_idf$word == "spouse",])
menWords$gender <- NA

for (val in unique(menWords$word)) {
  menWords$gender[menWords$word == "male"] <- "m"
  menWords$gender[menWords$word == "men"] <- "m"
  menWords$gender[menWords$word == "father"] <- "m"
  menWords$gender[menWords$word == "brother"] <- "m"
  menWords$gender[menWords$word == "son"] <- "m"
  menWords$gender[menWords$word == "husband"] <- "m"
  menWords$gender[menWords$word == "patriarchy"] <- "m"
  menWords$gender[menWords$word == "patrimony"] <- "m"
  menWords$gender[menWords$word == "man"] <- "m"
  menWords$gender[menWords$word == "people"] <- "n"
  menWords$gender[menWords$word == "person"] <- "n"
  menWords$gender[menWords$word == "partner"] <- "n"
  menWords$gender[menWords$word == "spouse"] <- "n"
  
}
menWords$gender[is.na(menWords$gender)] <- "f"
#male vs female timeline
ggplot(menWords, aes(x = ID, y = n/sum, fill = gender)) + 
  geom_bar(stat = "identity", position = position_dodge()) +
  xlab("Text ID") +
  ylab("Frequency") +
  ggtitle("Frequency of Gendered Terms by Text")
ggplot(menWords, aes(x = Publication.Year, y = n/sum, fill = gender)) + 
  geom_bar(stat = "identity", position = position_dodge()) +
  #geom_line(stat = "identity", aes(color = gender)) +
  xlab("Year") +
  ylab("Frequency") +
  ggtitle("Frequency of Gendered Terms by Year")
ggplot(menWords, aes(x = country, y = n/sum, fill = gender)) + 
  geom_bar(stat = "identity", position = position_dodge()) +
  xlab("Country of Publication") +
  ylab("Frequency") +
  ggtitle("Frequency of Gendered Terms by Country of Publication")

##race##
raceWords <- book_tf_idf[book_tf_idf$word == "white",]
raceWords <- rbind(raceWords, book_tf_idf[book_tf_idf$word == "black",])
raceWords <- rbind(raceWords, book_tf_idf[book_tf_idf$word == "african",])
raceWords <- rbind(raceWords, book_tf_idf[book_tf_idf$word == "creole",])
raceWords <- rbind(raceWords, book_tf_idf[book_tf_idf$word == "indian",])

#latin and brown don't appear very much; asian and mestizo don't appear at all
ggplot(raceWords, aes(x = ID, y = n/sum, fill = word)) + 
  geom_bar(stat = "identity", position = position_dodge()) +
  xlab("Text ID") +
  ylab("Frequency") +
  ggtitle("Frequency of Racial Terms by Text")
ggplot(raceWords, aes(x = Publication.Year, y = n/sum, fill = word)) + 
  #geom_bar(stat = "identity", position = position_dodge()) +
  geom_line(stat = "identity", aes(color = word)) +
  xlab("Year") +
  ylab("Frequency") +
  ggtitle("Frequency of Racial Terms by Year")
ggplot(raceWords, aes(x = country, y = n/sum, fill = word)) + 
  geom_bar(stat = "identity", position = position_dodge()) +
  xlab("Country of Publication") +
  ylab("Frequency") +
  ggtitle("Frequency of Racial Terms by Country of Publication")

##look for different critical methods##
#these words were determined by looking through the higher frequency, middle range rarity words in book_tf_idf
critWords <- book_tf_idf[book_tf_idf$word == "psychological",]
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "madness",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "violence",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "schizophrenia",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "consciousness",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "sense",])

critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "postcolonial",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "post-colonial",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "colonize",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "colonized",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "colonization",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "colonialism",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "colonial",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "subaltern",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "emancipation",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "oppression",])

critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "historical",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "biography",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "biographical",])

critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "money",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "class",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "wealth",])

critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "representation",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "race",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "racial",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "white",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "black",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "african",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "creole",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "indian",])

critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "british",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "British",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "England",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "england",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "indies",])
critWords <- rbind(critWords, book_tf_idf[book_tf_idf$word == "Indies",])

critWords$method <- NA
for (val in unique(critWords$word)) {
  critWords$method[critWords$word == "psychological"] <- "psychoanalytic"
  critWords$method[critWords$word == "madness"] <- "psychoanalytic"
  critWords$method[critWords$word == "violence"] <- "psychoanalytic"
  critWords$method[critWords$word == "schizophrenia"] <- "psychoanalytic"
  critWords$method[critWords$word == "consciousness"] <- "psychoanalytic"
  critWords$method[critWords$word == "sense"] <- "psychoanalytic"
  
  critWords$method[critWords$word == "postcolonial"] <- "postcolonialism"
  critWords$method[critWords$word == "post-colonial"] <- "postcolonialism"
  critWords$method[critWords$word == "colonize"] <- "postcolonialism"
  critWords$method[critWords$word == "colonized"] <- "postcolonialism"
  critWords$method[critWords$word == "colonization"] <- "postcolonialism"
  critWords$method[critWords$word == "colonialism"] <- "postcolonialism"
  critWords$method[critWords$word == "colonial"] <- "postcolonialism"
  critWords$method[critWords$word == "subaltern"] <- "postcolonialism"
  critWords$method[critWords$word == "emancipation"] <- "postcolonialism"
  critWords$method[critWords$word == "oppression"] <- "postcolonialism"
  
  critWords$method[critWords$word == "historical"] <- "historical"
  critWords$method[critWords$word == "biography"] <- "historical"
  critWords$method[critWords$word == "biographical"] <- "historical"
  
  critWords$method[critWords$word == "money"] <- "classism"
  critWords$method[critWords$word == "class"] <- "classism"
  critWords$method[critWords$word == "wealth"] <- "classism"
  
  critWords$method[critWords$word == "representation"] <- "race"
  critWords$method[critWords$word == "race"] <- "race"
  critWords$method[critWords$word == "racial"] <- "race"
  critWords$method[critWords$word == "black"] <- "race"
  critWords$method[critWords$word == "white"] <- "race"
  critWords$method[critWords$word == "creole"] <- "race"
  critWords$method[critWords$word == "african"] <- "race"
  critWords$method[critWords$word == "indian"] <- "race"

  critWords$method[critWords$word == "british"] <- "geographic"
  critWords$method[critWords$word == "British"] <- "geographic"
  critWords$method[critWords$word == "england"] <- "geographic"
  critWords$method[critWords$word == "England"] <- "geographic"
  critWords$method[critWords$word == "indies"] <- "geographic"
  critWords$method[critWords$word == "Indies"] <- "geographic"
}
ggplot(critWords, aes(x = ID, y = n/sum, fill = method)) + 
  geom_bar(stat = "identity", position = position_dodge()) +
  xlab("Text ID") +
  ylab("Frequency") +
  ggtitle("Frequency of Critical Term Types by Text")
ggplot(critWords, aes(x = Publication.Year, y = n/sum, fill = method)) + 
  geom_bar(stat = "identity", position = position_dodge()) +
  xlab("Year") +
  ylab("Frequency") +
  ggtitle("Frequency of Critical Term Types by Year")
ggplot(critWords, aes(x = country, y = n/sum, fill = method)) + 
  geom_bar(stat = "identity", position = position_dodge()) +
  xlab("Country of Publication") +
  ylab("Frequency") +
  ggtitle("Frequency of Critical Term Types by Country of Publication")
#sentiment analysis? -> see who is more positive vs negative or more strong vs neutral

##topic model?
#book_tf_idf[book_tf_idf$word == "wide sargasso sea",]

#####
#install.packages("topicmodels")
library(topicmodels)
data("AssociatedPress")

feministDTM <- feministClean%>%
  cast_dtm(title, word, n)

feministLDA <- LDA(feministDTM, k=2, control = list(seed=1234))
feministTopics <- tidy(feministLDA, matrix = "beta")
feministTopics
feministTopics[feministTopics$term == "feminist",]

library(ggplot2)
library(dplyr)
feministTopicsTerms <- feministTopics %>%
  group_by(topic) %>%
  slice_max(beta, n = 10) %>% 
  ungroup() %>%
  arrange(topic, -beta)

feministTopicsTerms %>%
  mutate(term = reorder_within(term, beta, topic)) %>%
  ggplot(aes(beta, term, fill = factor(topic))) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~ topic, scales = "free") +
  scale_y_reordered()

#making sure the words are different between the topics
library(tidyr)

beta_wide <- feministTopics %>%
  mutate(topic = paste0("topic", topic)) %>%
  pivot_wider(names_from = topic, values_from = beta) %>% 
  filter(topic1 > .001 | topic2 > .001) %>%
  mutate(log_ratio = log2(topic2 / topic1))

beta_wide %>%
  ggplot(aes(log_ratio, term)) +
  geom_bar(stat = "identity")

###sentiment analysis###
#install.packages("textdata")
library(textdata)
nrc_joy <- get_sentiments("nrc")
afinn_joy <- get_sentiments("afinn")
#remove all sentiments except negative/positive
nrc_joy <- nrc_joy[nrc_joy$sentiment == "positive" | nrc_joy$sentiment == "negative",]
fem_nrc <- nrc_joy %>%
  inner_join(feministClean)
fem_afinn <- afinn_joy %>%
  inner_join(feministClean)
#need to make a summary doc of all the info for each text
feministCleanSumm <- data.frame("ID" = unique(feministClean$ID), "title" = unique(feministClean$title), "sum" = unique(feministClean$sum))
for(val in unique(feministClean$title)) {
  feministCleanSumm$author[feministCleanSumm$title == val] <- feminist$Author[feminist$title == val]
  feministCleanSumm$Publication.Year[feministCleanSumm$title == val] <- feministClean$Publication.Year[feministClean$title == val]
  feministCleanSumm$Publication.Journal[feministCleanSumm$title == val] <- feminist$Publication.Journal[feminist$title == val]
  feministCleanSumm$sentiment[feministCleanSumm$title == val] <- mean(fem_afinn$value[fem_afinn$title == val])
  feministCleanSumm$SD_sentiment[feministCleanSumm$title == val] <- sd(fem_afinn$value[fem_afinn$title == val])
  feministCleanSumm$SE_sentiment[feministCleanSumm$title == val] <- sd(fem_afinn$value[fem_afinn$title == val])/sqrt(length(fem_afinn$value[fem_afinn$title == val]))
}
feministCleanSumm %>%
  ggplot(aes(x=ID, y=sentiment)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin=sentiment - SE_sentiment, ymax=sentiment + SE_sentiment)) +
  xlab("Text") +
  ylab("Average Sentiment") +
  ggtitle("Average Sentiment by Text")

feministCleanSummYear <- data.frame("Publication.Year" = unique(feministClean$Publication.Year))
for(val in unique(feministClean$Publication.Year)) {
  feministCleanSummYear$sentiment[feministCleanSummYear$Publication.Year == val] <- mean(fem_afinn$value[fem_afinn$Publication.Year == val])
  feministCleanSummYear$SD_sentiment[feministCleanSummYear$Publication.Year == val] <- sd(fem_afinn$value[fem_afinn$Publication.Year == val])
  feministCleanSummYear$SE_sentiment[feministCleanSummYear$Publication.Year == val] <- sd(fem_afinn$value[fem_afinn$Publication.Year == val])/
    sqrt(length(fem_afinn$value[fem_afinn$Publication.Year == val]))
}
feministCleanSummYear %>%
  ggplot(aes(x=Publication.Year, y=sentiment)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin=sentiment - SE_sentiment, ymax=sentiment + SE_sentiment)) +
  xlab("Year") +
  ylab("Average Sentiment") +
  ggtitle("Average Sentiment by Year")

feministCleanSummPlace <- data.frame("country" = unique(feministClean$country))
feministCleanSummPlace$country <- as.character(feministCleanSummPlace$country)
for(val in unique(feministClean$country)) {
  feministCleanSummPlace$sentiment[feministCleanSummPlace$country == val] <- mean(fem_afinn$value[fem_afinn$country == val])
  feministCleanSummPlace$SD_sentiment[feministCleanSummPlace$country == val] <- sd(fem_afinn$value[fem_afinn$country == val])
  feministCleanSummPlace$SE_sentiment[feministCleanSummPlace$country == val] <- sd(fem_afinn$value[fem_afinn$country == val])/
    sqrt(length(fem_afinn$value[fem_afinn$country == val]))
}
feministCleanSummPlace %>%
  ggplot(aes(x=country, y=sentiment)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin=sentiment - SE_sentiment, ymax=sentiment + SE_sentiment)) +
  xlab("Country of Publication") +
  ylab("Average Sentiment") +
  ggtitle("Average Sentiment by Country of Publication")


###make a table to put on website for reference###
feministRef <- data.frame("ID" = unique(feminist$ID), "title" = unique(feminist$title), "publication.year" = NA)
for(val in unique(feminist$title)) {
  feministRef$publication.year[feministRef$title == val] <- feminist$Publication.Year[feminist$title == val]
}
write.csv(feministRef, "C:/Users/feministRef.csv")







#to graph by year, I need to make another summary file that goes by year instead of by title
  #I can't build it from the current summary file; must make a new one (relatively easy though)
feministYear <- feministClean[,-c(2)]
feministYearSumm <- data.frame("ID" = unique(feministClean$Publication.Year), "Yearly.Frequency" = NA, "sentiment" = NA, "SD_sentmient" = NA,
                               "SE_sentiment" = NA)

feministClean$Publication.Year <- as.factor(feministClean$Publication.Year)
for(val in unique(feministClean$Publication.Year)) {
  feministYearSumm$Yearly.Frequency[feministYearSumm$Publication.Year == val] <- nrow(fem_afinn[fem_afinn$Publication.Year == val,])
  
  feministYearSumm$sentiment[feministYearSumm$Publication.Year == val] <- mean(fem_afinn$value[fem_afinn$Publication.Year == val])
  feministYearSumm$SD_sentiment[feministYearSumm$Publication.Year == val] <- sd(fem_afinn$value[fem_afinn$Publication.Year == val])
  feministYearSumm$SE_sentiment[feministYearSumm$Publication.Year == val] <- sd(fem_afinn$value[fem_afinn$Publication.Year == val])/sqrt(length(fem_afinn$value[fem_afinn$title == val]))
}


feministYearSumm %>%
  ggplot(aes(x=Publication.Year, y=sentiment)) +
  geom_bar(stat = "identity") +
  geom_errorbar(aes(ymin=sentiment - SE_sentiment, ymax=sentiment + SE_sentiment))

#can customize stop words if necessary
custom_stop_words <- bind_rows(tibble(word = c("miss"),  
                                      lexicon = c("custom")), 
                               stop_words)





